ENT.Type 			= "anim"
ENT.PrintName		= "Spike"
ENT.Author			= "UVChief"
ENT.Spawnable			= false
ENT.AdminSpawnable		= false
