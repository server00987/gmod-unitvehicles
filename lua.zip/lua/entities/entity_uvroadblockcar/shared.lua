ENT.Type 			= "anim"
ENT.PrintName		= "RoadblockCar"
ENT.Author			= "UVChief"
ENT.Spawnable			= false
ENT.AdminSpawnable		= false
