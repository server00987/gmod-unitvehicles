ENT.Type = "anim"
ENT.PrintName = "Repair Shop"
ENT.Author = "Mechanic"
ENT.Purpose = "Repair your vehicles here."
ENT.Category = "Unit Vehicles"
ENT.Spawnable = true
ENT.AdminOnly = false
