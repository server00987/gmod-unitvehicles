ENT.Type 			= "anim"
ENT.PrintName		= "Bomb"
ENT.Author			= "UVChief"
ENT.Spawnable			= false
ENT.AdminSpawnable		= false
