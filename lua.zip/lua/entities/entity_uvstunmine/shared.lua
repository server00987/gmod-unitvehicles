ENT.Type 			= "anim"
ENT.PrintName		= "Mine"
ENT.Author			= "Razor"
ENT.Spawnable			= false
ENT.AdminSpawnable		= false
